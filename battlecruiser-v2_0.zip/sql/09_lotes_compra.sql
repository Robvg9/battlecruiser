-- ============================================================
-- BATTLECRUISER — Sesión 9: Lotes de compra (FIFO) + RPC de compra
-- ============================================================

-- Asegura que "stock" tenga una sola fila por combinación producto+almacén
-- (necesario para que el ON CONFLICT de más abajo funcione). Si ya existe,
-- este comando no hace nada.
do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'stock_producto_almacen_key'
  ) then
    alter table stock add constraint stock_producto_almacen_key unique (producto_id, almacen_id);
  end if;
end $$;

create table if not exists lotes_compra (
  id uuid primary key default gen_random_uuid(),
  producto_id uuid not null references productos(id),
  almacen_id uuid not null references almacenes(id),
  cantidad_inicial numeric not null check (cantidad_inicial > 0),
  cantidad_restante numeric not null check (cantidad_restante >= 0),
  costo_unitario numeric not null check (costo_unitario >= 0),
  fecha_compra timestamptz not null default now()
);

alter table lotes_compra enable row level security;
create policy lotes_ver on lotes_compra for select using (tiene_permiso('productos','ver'));

-- RPC atómica: registrar una compra (crea el lote + suma stock).
-- Nunca se hace .insert()/.update() directo desde el cliente para esto.
create or replace function registrar_compra(
  p_producto_id uuid,
  p_almacen_id uuid,
  p_cantidad numeric,
  p_costo_unitario numeric
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_lote_id uuid;
begin
  if not tiene_permiso('productos','crear') then
    raise exception 'Sin permiso para registrar compras';
  end if;
  if p_cantidad <= 0 then
    raise exception 'La cantidad debe ser mayor a cero';
  end if;

  insert into lotes_compra (producto_id, almacen_id, cantidad_inicial, cantidad_restante, costo_unitario)
  values (p_producto_id, p_almacen_id, p_cantidad, p_cantidad, p_costo_unitario)
  returning id into v_lote_id;

  insert into stock (producto_id, almacen_id, cantidad, minimo)
  values (p_producto_id, p_almacen_id, p_cantidad, 0)
  on conflict (producto_id, almacen_id)
    do update set cantidad = stock.cantidad + excluded.cantidad;

  return v_lote_id;
end;
$$;
