-- ============================================================
-- BATTLECRUISER — Sesión 8: Roles y permisos granulares
-- Correr en el SQL Editor de Supabase, en orden, una sola vez.
-- Reemplaza la política temporal "temp_authenticated_all".
-- ============================================================

-- 1) Roles con nombre libre (Roberto los define, no son fijos)
create table if not exists roles (
  id uuid primary key default gen_random_uuid(),
  nombre text not null unique,
  creado_en timestamptz not null default now()
);

-- 2) Matriz de permisos: por rol, por sección, por acción
create table if not exists permisos (
  id uuid primary key default gen_random_uuid(),
  role_id uuid not null references roles(id) on delete cascade,
  seccion text not null check (seccion in (
    'productos','categorias','almacenes','stock',
    'transferencias','vales_salida','ventas','reportes','usuarios'
  )),
  accion text not null check (accion in ('ver','crear','editar','borrar')),
  permitido boolean not null default false,
  unique (role_id, seccion, accion)
);

-- 3) Usuarios de la app, uno a uno con auth.users, con su rol asignado
create table if not exists usuarios (
  id uuid primary key references auth.users(id) on delete cascade,
  nombre text not null,
  role_id uuid references roles(id) on delete set null,
  activo boolean not null default true,
  creado_en timestamptz not null default now()
);

-- 4) Función helper: ¿el usuario actual tiene permiso X en la sección Y?
--    security definer para poder leer "permisos" aunque el usuario no tenga
--    acceso directo a esa tabla.
create or replace function tiene_permiso(p_seccion text, p_accion text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select coalesce(
    (
      select p.permitido
      from usuarios u
      join permisos p on p.role_id = u.role_id
      where u.id = auth.uid()
        and u.activo = true
        and p.seccion = p_seccion
        and p.accion = p_accion
    ),
    false
  );
$$;

-- 5) Rol inicial "Dueño" con todos los permisos, y asignación al usuario
--    actual de Roberto (ajustar el email antes de correr esta parte).
insert into roles (nombre) values ('Dueño')
  on conflict (nombre) do nothing;

insert into permisos (role_id, seccion, accion, permitido)
select r.id, seccion, accion, true
from roles r
cross join (values
  ('productos'), ('categorias'), ('almacenes'), ('stock'),
  ('transferencias'), ('vales_salida'), ('ventas'), ('reportes'), ('usuarios')
) as s(seccion)
cross join (values ('ver'), ('crear'), ('editar'), ('borrar')) as a(accion)
where r.nombre = 'Dueño'
on conflict (role_id, seccion, accion) do nothing;

-- ⚠️ AJUSTAR el email real de Roberto antes de correr esta línea:
insert into usuarios (id, nombre, role_id)
select au.id, 'Roberto', r.id
from auth.users au, roles r
where au.email = 'CAMBIAR-POR-EL-EMAIL-DE-ROBERTO'
  and r.nombre = 'Dueño'
on conflict (id) do update set role_id = excluded.role_id;

-- 6) Habilitar RLS y quitar la política temporal en todas las tablas base
alter table categorias enable row level security;
alter table almacenes enable row level security;
alter table productos enable row level security;
alter table stock enable row level security;
alter table roles enable row level security;
alter table permisos enable row level security;
alter table usuarios enable row level security;

drop policy if exists temp_authenticated_all on categorias;
drop policy if exists temp_authenticated_all on almacenes;
drop policy if exists temp_authenticated_all on productos;
drop policy if exists temp_authenticated_all on stock;

-- 7) Políticas granulares reales (una por sección/acción, usando tiene_permiso)
create policy categorias_ver on categorias for select using (tiene_permiso('categorias','ver'));
create policy categorias_crear on categorias for insert with check (tiene_permiso('categorias','crear'));
create policy categorias_editar on categorias for update using (tiene_permiso('categorias','editar'));
create policy categorias_borrar on categorias for delete using (tiene_permiso('categorias','borrar'));

create policy almacenes_ver on almacenes for select using (tiene_permiso('almacenes','ver'));
create policy almacenes_crear on almacenes for insert with check (tiene_permiso('almacenes','crear'));
create policy almacenes_editar on almacenes for update using (tiene_permiso('almacenes','editar'));
create policy almacenes_borrar on almacenes for delete using (tiene_permiso('almacenes','borrar'));

create policy productos_ver on productos for select using (tiene_permiso('productos','ver'));
create policy productos_crear on productos for insert with check (tiene_permiso('productos','crear'));
create policy productos_editar on productos for update using (tiene_permiso('productos','editar'));
create policy productos_borrar on productos for delete using (tiene_permiso('productos','borrar'));

create policy stock_ver on stock for select using (tiene_permiso('stock','ver'));
create policy stock_editar on stock for update using (tiene_permiso('stock','editar'));

-- roles/permisos/usuarios: solo quien tiene permiso 'usuarios'
create policy usuarios_ver on usuarios for select using (
  id = auth.uid() or tiene_permiso('usuarios','ver')
);
create policy roles_ver on roles for select using (tiene_permiso('usuarios','ver'));
create policy permisos_ver on permisos for select using (tiene_permiso('usuarios','ver'));
create policy roles_admin on roles for all using (tiene_permiso('usuarios','editar'));
create policy permisos_admin on permisos for all using (tiene_permiso('usuarios','editar'));
create policy usuarios_admin on usuarios for update using (tiene_permiso('usuarios','editar'));
