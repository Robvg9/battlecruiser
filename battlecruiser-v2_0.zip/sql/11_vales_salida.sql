-- ============================================================
-- BATTLECRUISER — Sesión 11: Vales de salida
-- ============================================================

create table if not exists vales_salida (
  id uuid primary key default gen_random_uuid(),
  producto_id uuid not null references productos(id),
  almacen_id uuid not null references almacenes(id),
  tipo text not null check (tipo in ('merma','donacion','regalo','vencido')),
  cantidad numeric not null check (cantidad > 0),
  estado text not null default 'completado' check (estado in ('completado','cancelado')),
  creado_por uuid references usuarios(id),
  fecha timestamptz not null default now()
);

alter table vales_salida enable row level security;
create policy vales_ver on vales_salida for select using (tiene_permiso('vales_salida','ver'));

-- RPC atómica: da de baja stock real por merma/donación/regalo/vencido,
-- consumiendo lotes FIFO igual que una venta.
create or replace function registrar_vale_salida(
  p_producto_id uuid,
  p_almacen_id uuid,
  p_tipo text,
  p_cantidad numeric
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_vale_id uuid;
  v_stock_actual numeric;
  v_restante numeric;
  v_lote record;
  v_tomar numeric;
begin
  if not tiene_permiso('vales_salida','crear') then
    raise exception 'Sin permiso para registrar vales de salida';
  end if;
  if p_cantidad <= 0 then
    raise exception 'La cantidad debe ser mayor a cero';
  end if;

  select cantidad into v_stock_actual from stock
    where producto_id = p_producto_id and almacen_id = p_almacen_id
    for update;

  if v_stock_actual is null or v_stock_actual < p_cantidad then
    raise exception 'Stock insuficiente para el vale de salida';
  end if;

  insert into vales_salida (producto_id, almacen_id, tipo, cantidad, creado_por)
  values (p_producto_id, p_almacen_id, p_tipo, p_cantidad, auth.uid())
  returning id into v_vale_id;

  v_restante := p_cantidad;
  for v_lote in
    select id, cantidad_restante from lotes_compra
    where producto_id = p_producto_id and almacen_id = p_almacen_id and cantidad_restante > 0
    order by fecha_compra asc
    for update
  loop
    exit when v_restante <= 0;
    v_tomar := least(v_lote.cantidad_restante, v_restante);
    update lotes_compra set cantidad_restante = cantidad_restante - v_tomar where id = v_lote.id;
    v_restante := v_restante - v_tomar;
  end loop;

  update stock set cantidad = cantidad - p_cantidad
    where producto_id = p_producto_id and almacen_id = p_almacen_id;

  return v_vale_id;
end;
$$;
