-- ============================================================
-- BATTLECRUISER — Sesión 10: Transferencias entre almacenes
-- ============================================================

create table if not exists transferencias (
  id uuid primary key default gen_random_uuid(),
  almacen_origen_id uuid not null references almacenes(id),
  almacen_destino_id uuid not null references almacenes(id),
  estado text not null default 'completada' check (estado in ('completada','cancelada')),
  creado_por uuid references usuarios(id),
  fecha timestamptz not null default now()
);

create table if not exists transferencias_lineas (
  id uuid primary key default gen_random_uuid(),
  transferencia_id uuid not null references transferencias(id) on delete cascade,
  producto_id uuid not null references productos(id),
  cantidad numeric not null check (cantidad > 0)
);

alter table transferencias enable row level security;
alter table transferencias_lineas enable row level security;
create policy transferencias_ver on transferencias for select using (tiene_permiso('transferencias','ver'));
create policy transferencias_lineas_ver on transferencias_lineas for select using (tiene_permiso('transferencias','ver'));

-- RPC atómica: mueve stock real de un almacén a otro, consumiendo lotes FIFO
-- del origen y creando lotes nuevos en el destino con el mismo costo unitario
-- (preserva costeo real, no promedia).
create or replace function registrar_transferencia(
  p_origen_id uuid,
  p_destino_id uuid,
  p_lineas jsonb  -- [{"producto_id": "...", "cantidad": 5}, ...]
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_transferencia_id uuid;
  v_linea jsonb;
  v_producto_id uuid;
  v_cantidad numeric;
  v_restante numeric;
  v_lote record;
  v_tomar numeric;
  v_stock_origen numeric;
begin
  if not tiene_permiso('transferencias','crear') then
    raise exception 'Sin permiso para registrar transferencias';
  end if;
  if p_origen_id = p_destino_id then
    raise exception 'El almacén origen y destino no pueden ser el mismo';
  end if;

  insert into transferencias (almacen_origen_id, almacen_destino_id, creado_por)
  values (p_origen_id, p_destino_id, auth.uid())
  returning id into v_transferencia_id;

  for v_linea in select * from jsonb_array_elements(p_lineas)
  loop
    v_producto_id := (v_linea->>'producto_id')::uuid;
    v_cantidad := (v_linea->>'cantidad')::numeric;

    if v_cantidad <= 0 then
      raise exception 'Cantidad inválida en línea de transferencia';
    end if;

    select cantidad into v_stock_origen from stock
      where producto_id = v_producto_id and almacen_id = p_origen_id
      for update;

    if v_stock_origen is null or v_stock_origen < v_cantidad then
      raise exception 'Stock insuficiente en el almacén origen para el producto %', v_producto_id;
    end if;

    insert into transferencias_lineas (transferencia_id, producto_id, cantidad)
    values (v_transferencia_id, v_producto_id, v_cantidad);

    -- Consumir lotes FIFO del origen (los más viejos primero)
    v_restante := v_cantidad;
    for v_lote in
      select id, cantidad_restante, costo_unitario from lotes_compra
      where producto_id = v_producto_id and almacen_id = p_origen_id and cantidad_restante > 0
      order by fecha_compra asc
      for update
    loop
      exit when v_restante <= 0;
      v_tomar := least(v_lote.cantidad_restante, v_restante);

      update lotes_compra set cantidad_restante = cantidad_restante - v_tomar
        where id = v_lote.id;

      -- Crear lote espejo en el destino con el mismo costo unitario real
      insert into lotes_compra (producto_id, almacen_id, cantidad_inicial, cantidad_restante, costo_unitario)
      values (v_producto_id, p_destino_id, v_tomar, v_tomar, v_lote.costo_unitario);

      v_restante := v_restante - v_tomar;
    end loop;

    update stock set cantidad = cantidad - v_cantidad
      where producto_id = v_producto_id and almacen_id = p_origen_id;

    insert into stock (producto_id, almacen_id, cantidad, minimo)
    values (v_producto_id, p_destino_id, v_cantidad, 0)
    on conflict (producto_id, almacen_id)
      do update set cantidad = stock.cantidad + excluded.cantidad;
  end loop;

  return v_transferencia_id;
end;
$$;
